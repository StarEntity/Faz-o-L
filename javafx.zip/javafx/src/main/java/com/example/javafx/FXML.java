package com.example.javafx;

public @interface FXML {
}
