package com.example.javafx;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class Controller extends Aluno{

    @FXML
    private TextField nomeField;

    @FXML
    private TextField primeiraNotaField;

    @FXML
    private TextField segundaNotaField;

    @FXML
    private TableView<Aluno> alunosTable;

    private ObservableList<Aluno> alunos = FXCollections.observableArrayList();

    public Controller(String nome, double primeiraNota, double segundaNota) {
        super(nome, primeiraNota, segundaNota);
    }

    @FXML
    public void cadastrar() {
        if (validarCampos()) {
            try {
                String nome = nomeField.getText();
                double primeiraNota = Double.parseDouble(primeiraNotaField.getText());
                double segundaNota = Double.parseDouble(segundaNotaField.getText());
                Aluno aluno = new Aluno(nome, primeiraNota, segundaNota);
                alunos.add(aluno);
                limparCampos();
            } catch (NumberFormatException e) {
                exibirMensagemDeErro("As notas devem ser números.");
            }
        }
    }

    @FXML
    public void buscar() {
        String nome = nomeField.getText();
        if (nome.isEmpty()) {
            alunosTable.setItems(alunos);
        } else {
            ObservableList<Aluno> resultados = FXCollections.observableArrayList();
            for (Aluno aluno : alunos) {
                if (aluno.getNome().contains(nome)) {
                    resultados.add(aluno);
                }
            }
            alunosTable.setItems(resultados);
        }
    }

    private boolean validarCampos() {
        StringBuilder mensagemDeErro = new StringBuilder();

        if (nomeField.getText().isEmpty()) {
            mensagemDeErro.append("O campo Nome é obrigatório.\n");
        }

        try {
            double primeiraNota = Double.parseDouble(primeiraNotaField.getText());
            if (primeiraNota < 0 || primeiraNota > 10) {
                mensagemDeErro.append("A primeira nota deve estar entre 0 e 10.\n");
            }
        } catch (NumberFormatException e) {
            mensagemDeErro.append("A primeira nota deve ser um número.\n");
        }

        try {
            double segundaNota = Double.parseDouble(segundaNotaField.getText());
            if (segundaNota < 0 || segundaNota > 10) {
                mensagemDeErro.append("A segunda nota deve estar entre 0 e 10.\n");
            }
        } catch (NumberFormatException e) {
            mensagemDeErro.append("A segunda nota deve ser um número.\n");
        }

        if (mensagemDeErro.length() > 0) {
            exibirMensagemDeErro(mensagemDeErro.toString());
            return false;
        } else {
            return true;
        }
    }

    private void exibirMensagemDeErro(String mensagem) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Erro");
        alert.setHeaderText(null);
        alert.setContentText(mensagem);
        alert.showAndWait();
    }

    private void limparCampos() {
        nomeField.setText("");
        primeiraNotaField.setText("");
        segundaNotaField.setText("");
    }
}
